.onLoad <- function(lib, pkg) {
  library.dynam("rmidi", pkg, lib)
}

